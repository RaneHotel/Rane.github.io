<?php

###############################################################################
#                               Habbink CMS                                   #
#                     Desarrollado por Matias Portales                        #
#                                                                             #
#    No seas tan cagado y ten algo de  Respeto por los derechos de autor      #
#                                                                             #
#                     Al descargar esta CMS tienes la                         #
#             Libertad de moficar tanto en Diseño como en codigo              #
#   (Siempre y cuando se respeten los derechos del autor original de la cms)  #
#                                                                             #
###############################################################################

require ('global.php');

include "Templates/Head.php";
include "Templates/Alertas.php";
include "Templates/Nav.php"; 
include "Templates/Body-Equipo.php"; 
include "Templates/Footer.php"; 

?>
