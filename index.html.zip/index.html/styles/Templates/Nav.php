<?php

$mipefil = $lang[16];

$ajuste = $lang[17];

$cerrar = $lang[18];

function whos_stats($id){ $f = json_decode(file_get_contents("http://whos.amung.us/stats/data/?k=".$id)); return $f->total_count; } 
$visitantes = whos_stats("$contador");

if ($visitantes == 1) {
  $texto_visitantes = $lang[14];
} else {
  $texto_visitantes = $lang[15];
}

$bannertop = "<div class='banner-top'><div class='container'><div class='visible-desktop'><div class='logo'><a href='$url/index'><img class='logo' src='$logo'></a><div class='contador-visitas'><b>$visitantes</b> $texto_visitantes</div></div>
</div></div>";

$menu = "<div class='banner-top'><div class='container'><div class='visible-desktop'><div class='logo'><a href='index'><img class='logo' src='$logo'></a><div class='contador-visitas'><b>$visitantes</b> $texto_visitantes</div></div>
</div></div>
      <nav class='navbar navbar-default'>
        <div class='container'>
          <div class='navbar-header'>
            <button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#navbar' aria-expanded='false' aria-controls='navbar'>
              <span class='sr-only'>Toggle navigation</span>
              <span class='icon-bar'></span>
              <span class='icon-bar'></span>
              <span class='icon-bar'></span>
            </button>
            <a class='navbar-brand' href=>Runom</a>
          </div>
          <div id='navbar' class='navbar-collapse collapse'>
            <ul class='nav navbar-nav'>
              <li><a href='$url/index'>AnaSayfa</a></li>
              <li><a href='$url/noticias'>Haberler</a></li>
			  <li><a href='$url/eventos'>Runo Etkinlik</a></li>
			  <li><a href='$url/furni'>Katalog</a></li>
			  
			  <li><a href='$url/equipo'>Ekip</a></li>
              <li><a href='$url/tienda'>Magaza</a></li>
              <li class='dropdown'>
                <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>Ekstralar<span class='caret'></span></a>
                <ul class='dropdown-menu'>
                  <li><a href='$url/usuarios'>Kullanıcı Listesi</a></li>
                  
                  <li><a href='$url/placas'>Rozetler</a></li>
                  <li><a href='$url/utilidad-grupos.php'>Grup Generator</a></li>
                  <li><a href='$url/utilidad-fonts.php'>Yazı Oluşturucu</a></li>
                </ul>
              </li>
            </ul>";
			
$query = $link->query('SELECT rank FROM usuarios WHERE username = "' .$username. '"');
while($row = mysqli_fetch_array($query))
{
  $rango = $row['rank'];
}

$query = $link->query('SELECT * FROM usuarios_amigos WHERE  (user = "' .$username. '") AND (estado_solicitud = "Pendiente")');
$solicitudes = mysqli_num_rows($query);

if ($solicitudes != 0) {
$notificacion_solicitud = "<span class='badge'>$solicitudes</span>";
} else { 
  $notificacion_solicitud = ""; 
}

if($_SESSION["logeado"] == "SI"){
	echo "$menu";
	echo '<ul class="nav navbar-nav navbar-right">';
  if("$rango" >= "3"){
      echo '<li><a href="hk/index.php?iniciohk">HK</a></li>';
  }
  ?>
<li class="dropdown">
  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo "$username"; ?> <span class="caret"></span></a>
  <ul class="dropdown-menu">
    <li><a href="perfil.php?user=<?php echo "$username"; ?>"><?php echo $lang[19]; ?></a></li>
    <li><a href="ajustes"><?php echo $lang[17]; ?></a></li>
	<li><a href="ajustes?mensajes"><?php echo $lang[20]; ?></a></li>
	<li><a href="ajustes?amigos"><?php echo $lang[21]; ?> <?php echo $notificacion_solicitud; ?></a></li>
	<li><a href="ajustes?regalos"><?php echo $lang[22]; ?></a></li>
  </ul>
</li>
  <li><a href="kernel/login/cerrar.php"><?php echo $lang[23]; ?></a></li>
    </ul> <?php
}  else {
	echo "$menu";
	echo '<ul class="nav navbar-nav navbar-right">
              <li><a href="login">'.$lang[24].'</a></li>
              <li><a href="registro">'.$lang[25].'</a></li>
            </ul>';
}
?>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>