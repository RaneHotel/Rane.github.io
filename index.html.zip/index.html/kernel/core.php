<?php

$host = "https://rane.github.io";
$user = "root";
$pass = "";
$db = "yok";

$contador = 'rg0uvc6goful';

?>