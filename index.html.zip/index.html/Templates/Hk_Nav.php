<?php
$query = $link->query('SELECT rank FROM usuarios WHERE username = "' .$username. '"');
while($row = mysqli_fetch_array($query))
{
  $rangouseruser = $row['rank'];
}

function whos_stats($id){ $f = json_decode(file_get_contents("http://whos.amung.us/stats/data/?k=".$id)); return $f->total_count; } 
$visitantes = whos_stats("$contador");

if ($visitantes == 1) {
  $texto_visitantes = $lang[14];
} else {
  $texto_visitantes = $lang[15];
}

if($_SESSION["logeado"] == "SI"){
echo "$bannertop";
	echo "
  <div class='banner-top'><div class='container'><div class='visible-desktop'><div class='logo'><a href='$url/index'><img class='logo' src='$logo'></a><div class='contador-visitas'>$visitantes $texto_visitantes</div></div></div></div>
  <nav class='navbar navbar-admin'>
          <div class='container'>
            <div class='navbar-header'>
              <button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#navbar' aria-expanded='false' aria-controls='navbar'>
                <span class='sr-only'>Toggle navigation</span>
                <span class='icon-bar'></span>
                <span class='icon-bar'></span>
                <span class='icon-bar'></span>
            </button>
            <a class='navbar-brand' href='$url'>Habnetim</a>
          </div>
            <div id='navbar' class='navbar-collapse collapse'>
              <ul class='nav navbar-nav'>
              <li><a href='$url/hk/index.php'>Ana Sayfa</a></li>";
if("$rangouser" >= "$rango4"){
echo  "<li class='dropdown'>
<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>Haber <span class='caret'></span></a>
<ul class='dropdown-menu'>
<li><a href='$url/hk/noticias.php'>Haber</a></li>
<li><a href='$url/hk/promos.php'>Ana Sayfa</a></li>
<li><a href='$url/hk/placas.php'>Rozet</a></li>
<li><a href='$url/hk/furni.php'>Katalog</a></li>
</ul>
</li>";
}

if("$rangouser" >= "$rango6"){
echo "<li class='dropdown'>
<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>Etkinlikler<span class='caret'></span></a>
<ul class='dropdown-menu'>
<li><a href='$url/hk/eventos.php'>Etkinlikler</a></li>
<li><a href='$url/hk/tienda.php'>Mağaza</a></li>
<li><a href='$url/hk/creditos.php'>Kredi Ver</a></li>
<li><a href='$url/hk/diamantes.php'>Ördek Ver</a></li>
</ul>
</li>";
}

if("$rangouser" >= "$rango3"){
echo  "<li class='dropdown'>
<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>Users <span class='caret'></span></a>
<ul class='dropdown-menu'>
<li><a href='$url/hk/users.php'>Users</a></li>
<li><a href='$url/hk/ban.php'>Ban</a></li>
<li><a href='$url/hk/comentarios.php'>Yorumlar</a></li>
<li><a href='$url/hk/reportes.php'>Raporlar</a></li>
<li><a href='$url/hk/mensajes.php'>$lang[20]</a></li>
<li><a href='$url/hk/regalos.php'>$lang[22]</a></li>
</ul>
</li>";
}

if("$rangouser" >= "$rango7"){
echo  "<li class='dropdown'>
<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>$rango_6 <span class='caret'></span></a>
<ul class='dropdown-menu'>
<li><a href='$url/hk/equipo.php'>$lang[6]</a></li>
<li><a href='$url/hk/rangos.php'>$lang[275]</a></li>
<li><a href='$url/hk/logs.php'>$lang[276]</a></li>
<li><a href='$url/hk/estadisticas.php'>$lang[277]</a></li>
<li><a href='$url/hk/catalogo_secciones.php'>$lang[278]</a></li>
</ul>
</li>";
}

if("$rangouser" >= "$rango7"){
echo  "<li class='dropdown'>
<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>$rango_7 <span class='caret'></span></a>
<ul class='dropdown-menu'>
<li><a href='$url/hk/mantenimiento.php'>$lang[279]</a></li>
<li><a href='$url/hk/configuracion.php'>$lang[280]</a></li>
<li><a href='$url/hk/radio.php'>$lang[281]</a></li>
<li><a href='$url/hk/xat.php'>$lang[5]</a></li>
</ul>
</li>";
}

echo '</ul>';
	echo '<ul class="nav navbar-nav navbar-right">';
  ?>
  <li><a href="<?php echo $url; ?>/kernel/login/cerrar.php"><?php echo $lang[18]; ?></a></li>
  <li><a href="<?php echo $url; ?>/index.php?hkcerrada"><?php echo $lang[283]; ?></a></li>
    </ul><?php
}
?>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>