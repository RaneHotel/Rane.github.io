<div class="container">
	<div class="row">
		<div class="col-md-4">
			<!-- Iniciar sesión en Index -->
			<?php 
			$resultado1 = $link->query("SELECT * FROM config WHERE id = 1");
			while($row = mysqli_fetch_array($resultado1)){
				$iniciar_sesion_op = $row['iniciar_sesion'];
				}

if($iniciar_sesion_op == 0){
 
 echo '<div class="panel panel-default">
			<div class="panel-heading oscuro">
				<h3 class="panel-title">'.$lang[24].'</h3>
			</div>
			<div class="panel-body">
				<div class="loginindex">
					<span style="font-size:19px;color:red;"><center>Bloqueado</center></span>
					<br>
					<span style="font-size:16px;color:red;">'.$lang[26].'</span>
				</div>
			</div>
		</div>
		<br>
		';

 } else { 
 	if($_SESSION["logeado"] !="SI"){ 

 	echo "<div class='panel panel-default'>
			<div class='panel-heading oscuro'><h3 class='panel-title'><div class='contedor-badge'><div class='icon-login'></div></div> $lang[24]</h3>
			</div>
			<div class='panel-body'>
				<div class='loginindex'>
					<form class='form form-signup' role='form' method='post' action='kernel/login/entrar.php'>
						<h5 class='colr bold mp'>$lang[27]</h5>
						<div class='form-group'>
							<div class='input-group'>
								<span class='input-group-addon'><span class='glyphicon glyphicon-user'></span></span>
								<input type='text' class='form-control' required='true' name='username' id='username' placeholder='$lang[27]'/>
							</div>
						</div>
						<h5 class='colr bold mp'>$lang[28]</h5>
						<div class='form-group'>
							<div class='input-group'>
								<span class='input-group-addon'><span class='glyphicon glyphicon-lock'></span></span>
								<input type='password' id='password' required='true' name='password' class='form-control' placeholder='$lang[28]'/>
							</div>
						</div>
						<a href='$url/recuperar.php' class='forgot'>$lang[29]</a>
						<input type='submit' name='Submit recordar' value='$lang[24]' class='btn btn-sm btn-primary btn-block loginbuttom'>
					</div>
				</div>
			</div>
			<br>"; 
		} }
			 ?> 

			<!-- Ultimas Placas subidas -->

			<div class="panel panel-default">
				<div class="panel-heading green">
					<h3 class="panel-title"><div class='contedor-badge'><div class='icon-badges'></div></div> <?php echo $lang[30]; ?></h3>
				</div>
				<div class="panel-body">
					<div class="placas">
						<?php
								$resultado = $link->query("SELECT * FROM placas ORDER BY id DESC limit 15");
							while($row = mysqli_fetch_array($resultado)){
								?>
						<div data-toggle="tooltip" title="<?php echo " $row[code] "; ?>
							" class="badgehabbink">
							<div class="iconbadge">
								<img src="<?php echo " $row[imagen] "; ?>" alt="" style="padding:7px;">
							</div>
						</div>
						<?php } ?>
					</div>
				</div>
			</div>
			<!-- Cierre de Placas subidas -->
			<br>
			<?php echo $cartel_radio; ?>
			<?php echo $cartel_publicidad; ?>
			<!-- Facebook -->
			<?php echo $redes_sociales; ?>
			<!-- Cierre Facebook -->
		</div>
		<div class="col-md-8">

		<div class="no-celular">
			<!-- Promociones -->
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
          <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
          <li data-target="#carousel-example-generic" data-slide-to="2"></li>
		  <li data-target="#carousel-example-generic" data-slide-to="3"></li>
		  <li data-target="#carousel-example-generic" data-slide-to="4"></li>
		  <li data-target="#carousel-example-generic" data-slide-to="5"></li>
        </ol>
        <div class="carousel-inner" role="listbox">

<?PHP
$resultado = $link->query("SELECT * FROM banner ORDER BY id DESC limit 6");
while($row = mysqli_fetch_array($resultado))
{
?>
          <div class="item <?php echo "$row[principal]"; ?>">
            <img style="border-radius:10px;" data-src="holder.js/1140x500/auto/#777:#555/text:First slide" alt="<?php echo $nameweb; ?>" src="<?php echo strip_tags($row[imagen]); ?>" data-holder-rendered="true">
			<div style="float:right;position: absolute;bottom: 0px;right: 0px;background-color: rgba(0, 0, 0, 0.42);width: 100%;border-radius: 0px 0px 10px 10px;padding: 15px;"><a href="<?php echo "$row[url_promo]"; ?>"><input class="btn btn-warning" type="button" value="<?php echo $lang[200]; ?>"></a></div>
      <div class="textpromo"><b><?php echo strip_tags($row[titulo]); ?></b><div class="textpromosmall"><?php echo strip_tags($row[texto]); ?></div></div>
          </div>
<?php
}
?>
				</div>
			</div>
			</div>
			<br>
			<!-- Ultimos Usuarios registrados -->
			<div class="panel panel-default">
				<div class="panel-heading blue">
					<h3 class="panel-title"><div class='contedor-badge'><div class='icon-users-new'></div></div> <?php echo $lang[32]; ?></h3>
				</div>
				<div class="panel-body">
					<div style="margin-left: 0px;" class="panel-users">
					<center>
						<?PHP 

	$resultado = $link->query("SELECT * FROM usuarios ORDER BY id DESC limit 5");
						while($row = mysqli_fetch_array($resultado)){
							?>
						<div class="usercontenedor">
							<center>
							<div class="userperfileindex">
								<img src="<?php echo " $row[avatar] "; ?>" alt="" style="width:100px;height:100px;">
							</div>
							<div class="nameuserperfil">
								<a style="color: #fff;" href="perfil.php?user=<?php echo $row['username'];?>"> <?php echo "$row[username]"; ?>
								</a>
							</div>
							</center>
						</div>
						<?php
					}
						?>
						</center>
					</div>
				</div>
			</div>
			<!-- Cierre de Ultimos Usuarios registrados -->
			
			<!-- Ultimas noticias Publicadas -->
				<div style="padding-top: 0px" class="panel-body">
					<?PHP 
						$resultado = $link->query("SELECT * FROM noticias ORDER BY id DESC limit 4");
					while($row = mysqli_fetch_array($resultado)){
						?>
						
<div style="background-image: url(<?php echo $row['imagen']; ?>);background-position: 50%;margin-bottom: 15px;border-radius: 5px" class="articulo">
    <a href="articulo.php?id=<?php echo $row['id']; ?>">
  <div class="contenedor-datos">
        <div class="contenedor-likes">
            <div style="float:left;font-size: 14px;"><i style="font-size: 11px;" class="material-icons">thumb_up</i> <?php echo $row['megusta']; ?></div>
            <div style="margin-left:10px;float:left;font-size: 14px;"><i style="font-size: 11px;" class="material-icons">thumb_down</i> <?php echo $row['no_megusta']; ?></div>
        </div>
        <p><span style="color: rgb(204, 204, 204);"><span class="datos-noticia"><?php echo $lang[34]; ?>: <?php echo "$row[fecha]"; ?> <span style="margin-left:15px;"><?php echo $lang[35]; ?>: <?php echo "$row[categoria]"; ?><span style="margin-left:15px;"><?php echo $lang[36]; ?>: <?php echo "$row[autor]"; ?></span></span>
          </span>
            </span>
    </p></div>
    <div style="height: 55px;position: relative;padding: 10px;float: left;width: 55%;background-color: rgba(0, 0, 0, 0.86);overflow: hidden;">
        <div class="titlesmallarticulo">
            <a href="articulo.php?id=<?php echo $row['id']; ?>">
                <?php echo "$row[titulo]"; ?>           </a>
        </div>
        <div style="color:#ccc;" class="resumen-noticia">
            <?php echo "$row[resumen]"; ?>                <br>
        </div>
        
    </div>
<div class="detalle-titulo"></div>

    </a>
</div>						<?php
						}
						?>
					</div>
				<!-- Cierre de Ultimas noticias Publicadas -->
			</div>
		</div>
	</div>