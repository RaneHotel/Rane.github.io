
<?php
require ('../global.php');
session_start();
if($_SESSION["logeado"] != "SI"){
header ("Location: ../index");
exit;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php echo"$meta"; ?>

<title><?php echo Habnetim; ?> - <?php echo"Hk"; ?></title>

<!-- Favicon -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="../images/ico/apple-touch-icon-144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="../images/ico/apple-touch-icon-114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="../images/apple-touch-icon-72.png">
<link rel="apple-touch-icon-precomposed" href="../images/ico/apple-touch-icon-57.png">
<link rel="shortcut icon" href="../images/ico/favicon.ico">
<link rel="shortcut icon" href="../images/favicon.ico">
<!-- Cierre de Favicon -->

    <!-- // Stylesheets // -->
    <link href="../styles/css/bootstrap.min.css" rel="stylesheet">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

	<script src="../styles/js/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="../stylescss/sweetalert.css">
<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css?family=Merriweather+Sans" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>

  <body>

  <div style='position: relative;margin-left: 20px'>

  <div class="idioma"><a href='<?php echo $url; ?>/?lang=es'><center><img data-toggle="tooltip" title='Español' src='<?php echo $url; ?>/images/es.png'></a></center></div>

 <div class="idioma"><a href='<?php echo $url; ?>/?lang=en'><center><img data-toggle="tooltip" title='English' src='<?php echo $url; ?>/images/en.png'></a></center></div>

  <div class="idioma"><a href='<?php echo $url; ?>/?lang=br'><center><img data-toggle="tooltip" title='Portugues' src='<?php echo $url; ?>/images/br.png'></a></center></div>

 </div>